#pragma GCC system_header
#pragma warning (disable: 4334)
#include "miniz.h"
#pragma warning (default: 4334)