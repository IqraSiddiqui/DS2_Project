#include "Front_Resource.h"
#include<sstream>
#include<iomanip>

#include"json.hpp"

Front_Resource::Front_Resource(){
_resource=make_shared<Resource>();
_resource->set_path(
    "/{src: [-+]?[0-500]*\\.?[0-500]*}"
);

_resource->set_method_handler("GET",[&](const shared_ptr<Session>session){
    get_handler(session);
});
}
tuple<float> Front_Resource::get_path_parameters(const shared_ptr<Session>session){
    const auto& request=session->get_request();
    auto src=atof(request->get_path_parameter("src").c_str());
    return((src));
}
int Front_Resource::calculate(float src){
    return(running(src));
}
string Front_Resource::to_json(int result){
    ostringstream str_stream;
    str_stream<<result;
    nlohmann::json jsonResult ={
        {"result",str_stream.str()}
    };
    return jsonResult.dump();
}
shared_ptr<Resource> Front_Resource::get_resource() const{
    return _resource;
}
void Front_Resource::get_handler(const shared_ptr<Session>session){
    const auto [src]=get_path_parameters(session);
    const auto result=calculate(src);
    auto content = to_json(result);
    session->close(OK,content,{{"Content-Length",to_string(content.size())}});
}

