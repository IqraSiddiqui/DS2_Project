#include"Front_Resource.h"
#include"FrontServiceSettingsFactory.h"
#include"FrontService.h"

int main(int argc, char** argv){
    auto resource_factory=make_shared<Front_Resource>();
    auto setting_factory=make_shared<FrontServiceSettingsFactory>();
    FrontService service{resource_factory,setting_factory};

    service.start();

    return 0;
}