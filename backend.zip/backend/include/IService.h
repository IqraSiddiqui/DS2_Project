#pragma once

class IService{
    public:
        virtual void start()=0;
};