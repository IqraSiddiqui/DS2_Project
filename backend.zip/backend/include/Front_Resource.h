#pragma once

#include "IResourceFactory.h"
#include<tuple>
#include<string>
#include "running.cpp"

class Front_Resource : public IResourceFactory{

public:
    Front_Resource();
    shared_ptr<Resource>get_resource() const final;
private:
    string to_json(int result);
    int calculate(float src);
    tuple<float>get_path_parameters(const shared_ptr<Session>session);
    void get_handler(const shared_ptr<Session>session);
    shared_ptr<Resource> _resource;
};