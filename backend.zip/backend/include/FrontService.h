#pragma once

#include"IService.h"
#include"IServiceSettingsFactory.h"
#include"IResourceFactory.h"



class FrontService: public IService{

public:
    FrontService(shared_ptr<IResourceFactory>resource_factory, shared_ptr<IServiceSettingsFactory>settings_factory);
    void start() final;

private:
    Service _service;
    shared_ptr<IServiceSettingsFactory>_settings_factory;
};